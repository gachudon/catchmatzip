package com.matzip.controller;

//import java.util.List;

//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.matzip.domain.MatzipUser;
//import com.matzip.domain.Matzip;
import com.matzip.service.MatzipService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/matzip/*")
@AllArgsConstructor
public class MatzipController {
	private MatzipService service;
	@GetMapping("/index")
	public void list(Model model) {
		log.info("list");
		model.addAttribute("mList",service.getList());
	}
	@GetMapping("/matzipinfo")
	public void matzipinfo(Model model) {
		log.info("getListAll");
		model.addAttribute("mListAll",service.getListAll());
		model.addAttribute("cList",service.getCategory());
	}
	@GetMapping("/join")
	public void join() {
		
	}
	@PostMapping("/join1")
	public String join1(MatzipUser matzipUser, RedirectAttributes rttr) {
		log.info("join1:"+matzipUser);
		service.join1(matzipUser);
		rttr.addFlashAttribute("result",matzipUser.getUserId());
		return "redirect:/matzip/login";
	}
}
