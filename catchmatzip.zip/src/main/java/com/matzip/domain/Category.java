package com.matzip.domain;

import lombok.Data;

@Data
public class Category {
	private String category;
}
