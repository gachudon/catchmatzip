package com.matzip.domain;

import lombok.Data;

@Data
public class Address {
	private Integer addressId;
	private String district;
	private String city;
}
